---
name: codex-quota-resume
description: 设置、更新、检查或停止 Codex 额度恢复后的自动续跑。Windows 桌面端优先安装零 Codex 用量的本地监控器；额度恢复五分钟后，只续跑有明确额度错误的原任务。仅询问方案时不启用。
---

# Codex 额度恢复续跑

让明确因五小时或周额度耗尽而中断的任务，在最晚重置时间五分钟后继续。安装或启用需要用户提出执行请求；只咨询时说明方案。

## 选择运行方式

Windows 桌面端优先使用本技能自带的本地监控器。它读取本机 Codex 会话日志并由任务计划程序运行，空闲检查不调用模型，因此不消耗 Codex 额度。

仅当本地会话日志、`codex queue`、Python 3 或任务计划程序不可用时，才使用宿主 heartbeat。heartbeat 每次运行都会消耗 Codex 额度，应先向用户说明这个差异，并放在独立短任务中。

## Windows 本地模式

1. 从本技能目录运行 `scripts/install_windows.ps1`。脚本先执行 `quota_watcher.py --self-test`，然后把监控器安装到 `%LOCALAPPDATA%\CodexQuotaWatcher`，注册 `Codex Quota Resume Watcher` 计划任务并立即验证一次。
2. 若已有同用途 heartbeat，将其暂停，避免两套监控重复续跑和消耗额度。不要修改其他自动任务。
3. 核验计划任务为 `Ready`、`LastTaskResult` 为 `0`，且安装文件与技能中的脚本哈希一致。配置成功不等于真实额度恢复已经发生；第一次真实中断仍是端到端验证。

监控器只接受会话日志中的明确证据：`task_complete` 的 `codex_error_info` 必须是 `usage_limit_exceeded`。它保留最后一个有效的五小时和周窗口，等待所有已耗尽窗口中最晚的 `resets_at` 再加五分钟。每次最多续跑一个最近任务，以任务、回合和重置时间去重；失败后五分钟再试。正常完成、取消、仍在运行或等待用户输入的任务不会被续跑。

续跑消息保持简短，只要求从原任务现状继续、读取已有 `PROGRESS.md`、自主完成和验证，并在必要时使用 computer use。消息不扩大原授权，也不覆盖暂停或取消。

常用操作：

- 查看：读取 `Get-ScheduledTask`、`Get-ScheduledTaskInfo` 及 `%LOCALAPPDATA%\CodexQuotaWatcher\state.json`；不要为查看状态调用模型额度查询。
- 停止：运行 `Disable-ScheduledTask -TaskName 'Codex Quota Resume Watcher'`。
- 恢复：启用并启动同一计划任务。
- 更新：从新版技能重新运行安装脚本，覆盖脚本并复用同名计划任务。
- 删除：仅在用户明确要求卸载时，注销同名计划任务并删除 `%LOCALAPPDATA%\CodexQuotaWatcher`。

电脑必须开机、保持唤醒且用户仍登录；关闭显示器或锁屏不影响本地任务。调用 `codex queue` 时需要 Codex 本地服务和网络可用。

## Heartbeat 备用模式

使用账户额度工具读取适用额度窗口，以所有已耗尽窗口中最晚的真实 `resetsAt` 加五分钟安排下一次运行；周额度耗尽时直接等待周恢复。没有窗口耗尽时按五小时窗口的下一次重置安排。不要把截图时间写死，不按小时轮询。

复用一个独立、短历史的 heartbeat。每次运行先读取最新额度并更新同一个计划，再最多检查三个近期候选任务；每个候选只读取最新两轮且不含工具输出。只向有明确额度错误、未完成且后来没有完成、取消或暂停证据的原任务发送一次续跑消息。等待额度、没有候选或状态不变时保持安静。

## 边界

不购买额度、不兑换重置券、不更改模型，不读取凭据或调用私有接口。分享包不包含个人路径、账户数据、任务 id、自动任务配置或运行状态。
